export const environment = {
  production: true,
  baseApi: 'http://localhost:5000',
};
