

export const systemRoles = {
    USER: 'User',
    ADMIN: "Admin",
    SUPER_ADMIN: 'Super Admin',
    DOCTOR: 'Doctor'
}