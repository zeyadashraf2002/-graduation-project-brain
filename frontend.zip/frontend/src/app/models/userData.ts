export class UserData{
    constructor(public token:any,public role:any){}
}