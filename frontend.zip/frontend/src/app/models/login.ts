export interface Login {
    token:string;
    role:string;
}
